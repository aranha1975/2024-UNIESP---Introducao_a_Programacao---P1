from importacao import importacao
importacao(str(input('Digite o nome do produto: ')),
           float(input('Digite o peso do produto em gramas: ')),
           float(input('Digite o valor do produto em dólar: ')))

