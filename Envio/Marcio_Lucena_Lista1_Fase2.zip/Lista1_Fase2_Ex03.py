carros=['GM', 'FIAT','Volkswagem', 'Ford', 'Honda', 'Toyota', 'Gurgel', 'Dodge']
carros.insert(3,'Hyundai')
carros.insert(4,'BMW')
carros.insert(5, 'Nissan')
carros[0]='Chevrolet'
carros.remove('Gurgel')
carros.sort()
print(carros)